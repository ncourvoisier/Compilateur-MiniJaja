package fr.femtost.disc.minijaja;

public class Tas {
}
