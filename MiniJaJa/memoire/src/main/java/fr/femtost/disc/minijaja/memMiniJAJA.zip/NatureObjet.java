package fr.femtost.disc.minijaja;

public enum NatureObjet {

    VAR,    //Variable
    VCST,   //Variable constante
    TAB,    //Tableau
    METH,
}
